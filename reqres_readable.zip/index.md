| seq | method | status | mime | size | url |
|---:|:--|:--:|:--|--:|:--|
| 286 | POST | 200 | application/json | 6425 | https://jaga.id/api/v5/captchas/generate |
| 288 | GET | 200 | application/json | 753 | https://jaga.id/api/v5/bpjs/detail?nik=3317110608050001&tgl_lahir=2005-08-06&captcha_uuid=6aacde23-7b3a-4270-bae4-dbf905f5661f&captcha_answer=K633v |
| 289 | POST | 200 | application/json | 6525 | https://jaga.id/api/v5/captchas/generate |
